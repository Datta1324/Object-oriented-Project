Name : "Amar Pay" 

Category : Mobile Banking System 

lang : Java 

Type : Console Based (No GUI)  

All rights reserved by <html><body><a href="https://www.facebook.com/sakibnjr7">©Najmus Sakib Nahid</a></body></html> (Student) at Daffodil International University.
