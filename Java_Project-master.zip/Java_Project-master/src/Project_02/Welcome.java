
package Project_02;

public class Welcome { //prints main screen
    public Welcome() {
        System.out.println("******************************************************");
        System.out.println("*                                                    *");
        System.out.println("*                  -------------------               *");
        System.out.println("*              >  WELCOME To Amar Pay  <             *");
        System.out.println("*                  -------------------               *");
        System.out.println("*                                                    *");
        System.out.println("******************************************************");
    }
}

